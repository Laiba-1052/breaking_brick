
package game;

import java.awt.event.ActionListener;
import java.awt.event.KeyListener;
import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Scanner;
import javax.swing.JFrame;
import javax.swing.Timer;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;


public class GamePlay extends JPanel implements KeyListener, ActionListener {
    
    
    
private boolean play=false;//game doesnot start on its own
private int score=0;//initial highscore
private int totalBricks=16;
private Timer timer;
private int delay=8;//pause 
private int playerX=310;
//setting dimension for  slide bar and ball
private int ballPosX=120;
private int ballPosY=350;
private int ballXdir=-1;
private int ballYdir=-2;
private MapGenerator map;
private int lives = 3;
private boolean[][] arr = new boolean[4][9];
private Graphics design;



public GamePlay(){
    
    map=new MapGenerator(4,4);
    addKeyListener(this);
    setFocusable(true);
    setFocusTraversalKeysEnabled(false);
    timer=new Timer(delay,this);
    timer.start();
    
}
public int getScore(){
return score;
}

//import graphics to design panel dimensions including ball slide bar and border
@Override
public void paint(Graphics design){
    this.design=design;
    
      //BACKGROUND
    design.setColor(Color.black);
    design.fillRect(1, 1,692,592);
    
     //DRAWING MAP
    map.draw((Graphics2D) design);
    
     //BORDERS
    design.setColor(Color.gray);
    design.fillRect(0, 0,3,592);
    design.fillRect(0, 0,692,3);
    design.fillRect(691, 0,3,592);
    
     //SCORE
    design.setColor(Color.white);
    design.setFont(new Font ("serif", Font.BOLD,25) );
    design.drawString(""+score, 590, 30);
    
     //LIVES
    design.setColor(Color.white);
    design.setFont(new Font ("serif", Font.BOLD,25) );
    design.drawString("Lifeline:  "+lives, 50, 30);
    
     //PADDLE
    design.setColor(Color.lightGray);
    design.fillRect(playerX, 550, 100, 8);
    
     //THE BALL
    design.setColor(Color.red);
    design.fillOval(ballPosX, ballPosY, 20, 20);
    //win
   if(totalBricks<=0){
      play=false;
      ballXdir=0;
      ballYdir=0;
      
      
      design.setColor(Color.RED);
      design.setFont(new Font ("serif", Font.BOLD,30) );
      design.drawString("YOU WON:", 260, 150);
      design.setFont(new Font ("serif", Font.BOLD,20) );
      design.drawString("PRESS D TO CONTINUE ", 230, 200);
      design.drawString("PRESS 1 TO NEW LEVEL ", 230, 250);
      design.drawString("PRESS ENTER FOR RESTART", 230, 300); 
}
   
      //lose
            
    if(lives==0){
      play=false;
      ballXdir=0;
      ballYdir=0;
      
      design.setColor(Color.RED);
      design.setFont(new Font ("serif", Font.BOLD,30) );
      design.drawString("GAME OVER,SCORES:"+score, 190, 300);
      design.setFont(new Font ("serif", Font.BOLD,20) );
      design.drawString("PRESS ENTER TO RESTART", 230, 350); }
    
    // to remove from memory and from component to save up storage
        design.dispose();}


    @Override
    public void keyPressed(KeyEvent ke) {
    
        if(ke.getKeyCode()==KeyEvent.VK_RIGHT){
            if(playerX>=600){
                playerX=600; 
            }
            else{
                moveRight();
            } 
        }
        if(ke.getKeyCode()==KeyEvent.VK_LEFT){
            if(playerX<10){
                playerX=10;
            }
            else{
                moveLeft();
            }
        }
        if(ke.getKeyCode()==KeyEvent.VK_ENTER){
            if(!play){
                play=true;
                ballPosX=120;
                ballPosY=350;
                ballXdir=-1;
                ballYdir=-2;
                playerX=310;
                score=0;
                lives=3;
                totalBricks=16;
                map=new MapGenerator(4,4);
                repaint();
            }
        }
        if(ke.getKeyCode()==KeyEvent.VK_D){
            if(!play){
                play=true;
                ballPosX=120;
                ballPosY=350;
                ballXdir=-1;
                ballYdir=-2;
                playerX=310;
                score=this.score;
                lives=this.lives;
                totalBricks=36;
                map=new MapGenerator(4,9);
                repaint();
            }
        }
        if(ke.getKeyCode()==KeyEvent.VK_1){
            if(!play){
                play=true;
                ballPosX=120;
                ballPosY=350;
                ballXdir=-1;
                ballYdir=-2;
                playerX=310;
                score=this.score;
                lives=this.lives;
                totalBricks=9;
                map=new MapGenerator(3,3);
                repaint();
            }
        }
    }

    public void moveRight(){
        play=true;
        playerX+=20;
    }
    public void moveLeft(){
        play=true;
        playerX-=20;
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        timer.start();
        if(play){
            if(new Rectangle(ballPosX,ballPosY,20,20).intersects(new Rectangle(playerX,550,100,8))){
                ballYdir =- ballYdir; 
            }
            
        // map intersection    
            A:for(int i=0;i<map.map.length;i++){
                for(int j=0;j<map.map[0].length;j++){
                    if(map.map[i][j]>0){
                        //score
                        int brickX=j*map.brickWidth+80;
                        int brickY=i*map.brickHeight+50;
                        int brickWidth = map.brickWidth;
                        int brickHeight = map.brickHeight;
                        
                        Rectangle rect = new Rectangle(brickX,brickY,brickWidth,brickHeight);
                        Rectangle ballRect = new Rectangle(ballPosX,ballPosY,20,20);
                        Rectangle brickRect = rect;
                    
                        if(ballRect.intersects(brickRect)){
                        if(!arr[i][j])
                        {
                            arr[i][j] = true;
                        map.hitBrick(i, j);
                        map.draw((Graphics2D)this.design);
                        score+=5;
                        }
                        
                        else if(arr[i][j] == true)
                        {
                        map.setBrickValue(0,i,j);
                        totalBricks--;   
                         score+=5;

                        }
                        else if(arr[i][j] == false)
                        {
                        map.setBrickValue(0,i,j);
                        totalBricks--;   
                         score+=5;

                        }

                        
               //when ball hit right or left of rick         
                if(ballPosX+19<=brickRect.x||ballPosX+1>=brickRect.x+brickRect.width){
                    ballXdir = - ballXdir;
                }
                //when ball hit topor bottom of brick
                else{
                    ballYdir = - ballYdir;
                }
                break A;
                    }
                }
            }
        }
            ballPosX+=ballXdir;
            ballPosY+=ballYdir;
            
            if(ballPosX<0){
                ballXdir=-ballXdir;
            }
            
            if(ballPosY<0){
                ballYdir=-ballYdir;
            }
            
            if(ballPosX>670){
                ballXdir=-ballXdir;
            }
            
            if(ballPosY>=570){
                lives--;
                resetBall();
                repaint();
            }
      
    }
            repaint();
    
    }

    private void resetBall() {
        ballPosX = 120;
        ballPosY = 350;
        ballXdir = -1;
        ballYdir = -2;
    }

    @Override
    public void keyTyped(KeyEvent e) {
       
    }

    @Override
    public void keyReleased(KeyEvent e) {
            }
}