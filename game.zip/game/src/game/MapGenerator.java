/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package game;

/**
 *
 * @author Hp
 */
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;

public class MapGenerator {
    public int map[][];
    public int brickWidth;
    public int brickHeight;
    
    public MapGenerator(int row,int col){
        map = new int[row][col];
        for(int i=0;i<map.length;i++){
            for(int j=0;j<map[0].length;j++){
               int r=(int)(Math.random()*4+1);
               map[i][j]=r;}}
        brickWidth=540/col;
        brickHeight=150/row;}
public void newdraw(Graphics2D g){
    
    for(int i=0;i<map.length;i++){
            for(int j=0;j<map[0].length;j++){
                if(map[i][j]>0){
              g.setColor(Color.white);
              g.fillRect(j * brickWidth + 80,i * brickHeight + 50, brickWidth, brickHeight);
                   
              g.setStroke(new BasicStroke(3));
              g.setColor(Color.black);
              g.drawRect(j * brickWidth + 80,i * brickHeight + 50, brickWidth, brickHeight);
                   
                }
            }
        }

}  
    
    
public void draw(Graphics2D g){
    
    for(int i=0;i<map.length;i++){
        
        for(int j=0;j<map[0].length;j++){
            
            if(map[i][j]>0){

                if(map[i][j]==1){
                    g.setColor(new Color(220,220,220));
                }
    
                if(map[i][j]==3){
                    g.setColor(new Color(150,150,150));
                }
    
                if(map[i][j]==4){
                    g.setColor(new Color(100,100,100));
                }
    
                if(map[i][j]==2){
                    g.setColor(new Color(200,200,200));
                }

            g.fillRect(j*brickWidth+80, i*brickHeight+50, brickWidth,brickHeight);
            g.setStroke(new BasicStroke(3));
            g.setColor(Color.black);
            g.drawRect(j*brickWidth+80, i*brickHeight+50, brickWidth, brickHeight);}
            }
        }
    }

    public void setBrickValue(int value,int row,int col){
        map[row][col]=value;
    }

    public void hitBrick(int row,int col){
        map[row][col]=1;
        if(map[row][col]<0){
            map[row][col]=0;
        
        }
    }
}

